<?php 
    const HOST = "localhost";
    const PORT = "3306";
    const DBNAME = "mangathequealex";
    const DBUSER = "root";
    const DBPASS = "";

    $dsn = "mysql:host=" . HOST . ";port=" . PORT . ";dbname=" . DBNAME;

?>